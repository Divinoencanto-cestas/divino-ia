"""Divino IA API. Python 3.11+. PostgreSQL in cloud; SQLite for local tests."""
import os, json, time, hmac, hashlib, secrets, base64, sqlite3, threading
from contextlib import contextmanager
from datetime import datetime, timezone
from fastapi import FastAPI, HTTPException, Depends, Header
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

DATABASE_URL=os.getenv('DATABASE_URL','sqlite:///./divino.db')
SECRET=os.getenv('APP_SECRET','')
if not SECRET or len(SECRET)<32: raise RuntimeError('Set APP_SECRET to a random string of at least 32 characters')
IS_PG=DATABASE_URL.startswith('postgresql://') or DATABASE_URL.startswith('postgres://')
if IS_PG: import psycopg
lock=threading.RLock()
@contextmanager
def db():
    if IS_PG:
        with psycopg.connect(DATABASE_URL, autocommit=False) as conn:
            with conn.cursor() as cur:
                yield DB(cur, True)
                conn.commit()
    else:
        path=DATABASE_URL.removeprefix('sqlite:///')
        with lock:
            conn=sqlite3.connect(path,timeout=30)
            conn.row_factory=sqlite3.Row
            conn.execute('PRAGMA foreign_keys=ON')
            try:
                yield DB(conn,False)
                conn.commit()
            except Exception:
                conn.rollback();raise
            finally:conn.close()
class DB:
    def __init__(self,c,pg):self.c,self.pg=c,pg
    def execute(self,q,args=()):
        q=q.replace('?', '%s') if self.pg else q
        self.c.execute(q,args)
        return self
    def one(self):
        row=self.c.fetchone()
        if row is None:return None
        if self.pg:return dict(zip([x.name for x in self.c.description],row))
        return dict(row)
    def all(self):
        rows=self.c.fetchall()
        if self.pg:return [dict(zip([x.name for x in self.c.description],r)) for r in rows]
        return [dict(r) for r in rows]

def init():
    with db() as d:
        idtype='BIGSERIAL PRIMARY KEY' if IS_PG else 'INTEGER PRIMARY KEY AUTOINCREMENT'
        for name,cols in [
            ('users','email TEXT UNIQUE NOT NULL, password TEXT NOT NULL, role TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1'),
            ('customers','name TEXT NOT NULL, phone TEXT, email TEXT, created_at TEXT NOT NULL'),
            ('products','name TEXT NOT NULL, price_cents INTEGER NOT NULL DEFAULT 0, stock INTEGER NOT NULL DEFAULT 0, active INTEGER NOT NULL DEFAULT 1'),
            ('orders','customer_id INTEGER NOT NULL REFERENCES customers(id), product_id INTEGER NOT NULL REFERENCES products(id), quantity INTEGER NOT NULL, unit_price_cents INTEGER NOT NULL, delivery_fee_cents INTEGER NOT NULL DEFAULT 0, status TEXT NOT NULL, delivery_address TEXT, delivery_date TEXT, card_message TEXT, created_at TEXT NOT NULL'),
            ('conversations','customer_id INTEGER NOT NULL REFERENCES customers(id), status TEXT NOT NULL DEFAULT \'open\', assigned_user_id INTEGER REFERENCES users(id), created_at TEXT NOT NULL'),
            ('messages','conversation_id INTEGER NOT NULL REFERENCES conversations(id), sender TEXT NOT NULL, body TEXT NOT NULL, created_at TEXT NOT NULL'),
            ('automations','key TEXT UNIQUE NOT NULL, enabled INTEGER NOT NULL DEFAULT 0, config_json TEXT NOT NULL DEFAULT \'{}\''),
            ('audit_logs','user_id INTEGER, action TEXT NOT NULL, entity TEXT NOT NULL, entity_id INTEGER, created_at TEXT NOT NULL')]:
            d.execute(f'CREATE TABLE IF NOT EXISTS {name} (id {idtype}, {cols})')
        for key in ['welcome','category','catalog','delivery_details','handoff','post_sale']:
            d.execute('INSERT INTO automations(key,enabled,config_json) VALUES(?,0,?) ON CONFLICT(key) DO NOTHING',(key,'{}'))

def now():return datetime.now(timezone.utc).isoformat()
def pwd_hash(p,salt=None):
    salt=salt or secrets.token_bytes(16)
    return base64.urlsafe_b64encode(salt).decode()+'.'+base64.urlsafe_b64encode(hashlib.scrypt(p.encode(),salt=salt,n=2**14,r=8,p=1)).decode()
def check_pwd(p,encoded):
    try:
        a,b=encoded.split('.'); salt=base64.urlsafe_b64decode(a)
        return hmac.compare_digest(pwd_hash(p,salt),encoded)
    except (ValueError,TypeError):return False

def token(uid):
    payload=f'{uid}:{int(time.time())+8*3600}'
    sig=hmac.new(SECRET.encode(),payload.encode(),hashlib.sha256).hexdigest()
    return base64.urlsafe_b64encode(f'{payload}:{sig}'.encode()).decode()
def user(authorization:str=Header(default='')):
    try:
        if not authorization.startswith('Bearer '):raise ValueError()
        raw=base64.urlsafe_b64decode(authorization[7:]).decode()
        uid,expiry,sig=raw.split(':')
        value=f'{uid}:{expiry}'
        if int(expiry)<time.time() or not hmac.compare_digest(sig,hmac.new(SECRET.encode(),value.encode(),hashlib.sha256).hexdigest()):raise ValueError()
        with db() as d:u=d.execute('SELECT id,email,role,active FROM users WHERE id=?',(int(uid),)).one()
        if not u or not u['active']:raise ValueError()
        return u
    except Exception:raise HTTPException(401,'Sessão inválida ou expirada')
def admin(u=Depends(user)):
    if u['role']!='admin':raise HTTPException(403,'Acesso restrito ao administrador')
    return u
def audit(d,u,action,entity,entity_id):d.execute('INSERT INTO audit_logs(user_id,action,entity,entity_id,created_at) VALUES(?,?,?,?,?)',(u['id'],action,entity,entity_id,now()))
def inserted(d,table):
    if d.pg:return d.execute('SELECT LASTVAL() AS id').one()['id']
    return d.execute('SELECT last_insert_rowid() AS id').one()['id']

app=FastAPI(title='Divino IA API',version='0.2.0',docs_url='/api/docs',openapi_url='/api/openapi.json')
origins=[x.strip() for x in os.getenv('CORS_ORIGINS','http://localhost:5173').split(',') if x.strip()]
app.add_middleware(CORSMiddleware,allow_origins=origins,allow_credentials=False,allow_methods=['GET','POST','PATCH'],allow_headers=['Authorization','Content-Type'])
@app.on_event('startup')
def startup():init()
class Login(BaseModel):email:str;password:str
class Setup(Login):pass
class Customer(BaseModel):name:str=Field(min_length=2,max_length=160);phone:str|None=None;email:str|None=None
class Product(BaseModel):name:str=Field(min_length=2,max_length=200);price_cents:int=Field(ge=0);stock:int=Field(ge=0)
class Order(BaseModel):customer_id:int;product_id:int;quantity:int=Field(ge=1);delivery_fee_cents:int=Field(default=0,ge=0);delivery_address:str|None=None;delivery_date:str|None=None;card_message:str|None=None
class Status(BaseModel):status:str
class Message(BaseModel):body:str=Field(min_length=1,max_length=4000)
class Automation(BaseModel):enabled:bool
class Staff(Login):role:str='attendant'
@app.get('/api/health')
def health():return {'status':'ok','version':'0.2.0'}
@app.post('/api/setup')
def setup(data:Setup, x_setup_key:str=Header(default='')):
    expected=os.getenv('SETUP_KEY','')
    if not expected or not hmac.compare_digest(x_setup_key,expected):raise HTTPException(403,'Chave de configuração inicial inválida')
    if len(data.password)<12:raise HTTPException(422,'Senha precisa ter pelo menos 12 caracteres')
    with db() as d:
        if d.execute('SELECT id FROM users LIMIT 1').one():raise HTTPException(403,'Configuração inicial já realizada')
        d.execute('INSERT INTO users(email,password,role) VALUES(?,?,?)',(data.email.lower(),pwd_hash(data.password),'admin'))
    return {'ok':True}
@app.post('/api/login')
def login(data:Login):
    with db() as d:u=d.execute('SELECT * FROM users WHERE email=?',(data.email.lower(),)).one()
    if not u or not u['active'] or not check_pwd(data.password,u['password']):raise HTTPException(401,'Credenciais inválidas')
    return {'access_token':token(u['id']),'user':{'id':u['id'],'email':u['email'],'role':u['role']}}
@app.get('/api/me')
def me(u=Depends(user)):return u
@app.post('/api/staff')
def staff(x:Staff,u=Depends(admin)):
    if x.role not in ('admin','attendant','florist','delivery'):raise HTTPException(422,'Perfil inválido')
    if len(x.password)<12:raise HTTPException(422,'Senha muito curta')
    with db() as d:
        if d.execute('SELECT id FROM users WHERE email=?',(x.email.lower(),)).one():raise HTTPException(409,'E-mail já cadastrado')
        d.execute('INSERT INTO users(email,password,role) VALUES(?,?,?)',(x.email.lower(),pwd_hash(x.password),x.role));i=inserted(d,'users');audit(d,u,'create','staff',i)
    return {'id':i}
@app.get('/api/customers')
def customers(u=Depends(user)):
    with db() as d:return d.execute('SELECT * FROM customers ORDER BY id DESC LIMIT 500').all()
@app.post('/api/customers')
def add_customer(x:Customer,u=Depends(user)):
    with db() as d:
        d.execute('INSERT INTO customers(name,phone,email,created_at) VALUES(?,?,?,?)',(x.name,x.phone,x.email,now()));i=inserted(d,'customers');audit(d,u,'create','customer',i)
    return {'id':i}
@app.get('/api/products')
def products(u=Depends(user)):
    with db() as d:return d.execute('SELECT * FROM products ORDER BY id DESC LIMIT 500').all()
@app.post('/api/products')
def add_product(x:Product,u=Depends(user)):
    with db() as d:
        d.execute('INSERT INTO products(name,price_cents,stock) VALUES(?,?,?)',(x.name,x.price_cents,x.stock));i=inserted(d,'products');audit(d,u,'create','product',i)
    return {'id':i}
@app.get('/api/orders')
def orders(u=Depends(user)):
    with db() as d:return d.execute('SELECT o.*,c.name AS customer_name,p.name AS product_name FROM orders o JOIN customers c ON c.id=o.customer_id JOIN products p ON p.id=o.product_id ORDER BY o.id DESC LIMIT 500').all()
@app.post('/api/orders')
def add_order(x:Order,u=Depends(user)):
    with db() as d:
        if not d.execute('SELECT id FROM customers WHERE id=?',(x.customer_id,)).one():raise HTTPException(404,'Cliente não encontrado')
        p=d.execute('SELECT * FROM products WHERE id=?',(x.product_id,)).one()
        if not p or not p['active']:raise HTTPException(404,'Produto indisponível')
        if p['stock']<x.quantity:raise HTTPException(409,'Estoque insuficiente')
        d.execute('UPDATE products SET stock=stock-? WHERE id=? AND stock>=?',(x.quantity,x.product_id,x.quantity))
        d.execute('INSERT INTO orders(customer_id,product_id,quantity,unit_price_cents,delivery_fee_cents,status,delivery_address,delivery_date,card_message,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)',(x.customer_id,x.product_id,x.quantity,p['price_cents'],x.delivery_fee_cents,'Novo',x.delivery_address,x.delivery_date,x.card_message,now()))
        i=inserted(d,'orders');audit(d,u,'create','order',i)
    return {'id':i}
STATUSES=['Novo','Aguardando pagamento','Em produção','Saiu para entrega','Entregue','Cancelado']
@app.patch('/api/orders/{oid}')
def change_order(oid:int,x:Status,u=Depends(user)):
    if x.status not in STATUSES:raise HTTPException(422,'Status inválido')
    with db() as d:
        old=d.execute('SELECT status,product_id,quantity FROM orders WHERE id=?',(oid,)).one()
        if not old:raise HTTPException(404,'Pedido não encontrado')
        if old['status']=='Cancelado' and x.status!='Cancelado':raise HTTPException(409,'Pedido cancelado não pode ser reaberto')
        if x.status=='Cancelado' and old['status']!='Cancelado':d.execute('UPDATE products SET stock=stock+? WHERE id=?',(old['quantity'],old['product_id']))
        d.execute('UPDATE orders SET status=? WHERE id=?',(x.status,oid));audit(d,u,'status','order',oid)
    return {'ok':True}
@app.get('/api/conversations')
def conversations(u=Depends(user)):
    with db() as d:return d.execute('SELECT v.*,c.name AS customer_name FROM conversations v JOIN customers c ON c.id=v.customer_id ORDER BY v.id DESC LIMIT 500').all()
@app.post('/api/conversations')
def add_conversation(customer_id:int,u=Depends(user)):
    with db() as d:
        if not d.execute('SELECT id FROM customers WHERE id=?',(customer_id,)).one():raise HTTPException(404,'Cliente não encontrado')
        d.execute('INSERT INTO conversations(customer_id,created_at) VALUES(?,?)',(customer_id,now()));i=inserted(d,'conversations');audit(d,u,'create','conversation',i)
    return {'id':i}
@app.get('/api/conversations/{cid}/messages')
def messages(cid:int,u=Depends(user)):
    with db() as d:return d.execute('SELECT * FROM messages WHERE conversation_id=? ORDER BY id LIMIT 1000',(cid,)).all()
@app.post('/api/conversations/{cid}/messages')
def add_message(cid:int,x:Message,u=Depends(user)):
    with db() as d:
        if not d.execute('SELECT id FROM conversations WHERE id=?',(cid,)).one():raise HTTPException(404,'Conversa não encontrada')
        d.execute('INSERT INTO messages(conversation_id,sender,body,created_at) VALUES(?,?,?,?)',(cid,'team',x.body,now()));i=inserted(d,'messages');audit(d,u,'create','message',i)
    return {'id':i,'note':'Mensagem interna, não enviada ao WhatsApp'}
@app.get('/api/automations')
def automations(u=Depends(user)):
    with db() as d:return d.execute('SELECT * FROM automations ORDER BY id').all()
@app.patch('/api/automations/{key}')
def automation(key:str,x:Automation,u=Depends(admin)):
    with db() as d:
        if not d.execute('SELECT id FROM automations WHERE key=?',(key,)).one():raise HTTPException(404,'Fluxo não encontrado')
        d.execute('UPDATE automations SET enabled=? WHERE key=?',(int(x.enabled),key));audit(d,u,'configure','automation',None)
    return {'ok':True,'note':'Configuração salva; execução automática ainda não conectada'}
@app.get('/api/overview')
def overview(u=Depends(user)):
    with db() as d:return {t:d.execute(f'SELECT COUNT(*) AS n FROM {t}').one()['n'] for t in ['customers','products','orders','conversations']}
