# Divino IA — implantação gratuita para TESTES

## Antes de começar
Este projeto é um protótipo. Não utilize dados reais de clientes, pagamentos ou atendimento comercial em produção sem auditoria de segurança, adequação à LGPD, backups e testes. Serviços gratuitos têm limites, suspensão por inatividade e podem mudar de condições.

## 1. GitHub
Crie um repositório **privado** e envie os arquivos deste projeto. Nunca envie `.env`, senhas ou chaves de API.

## 2. Neon (PostgreSQL)
Crie um projeto no Neon, copie a string de conexão PostgreSQL com SSL e guarde-a em segredo. Confirme os limites do plano gratuito no site do provedor.

## 3. Render (API)
No Render, crie um serviço web a partir do repositório. Pode usar o arquivo `render.yaml` (Blueprint), verificando se o plano free está disponível. O `rootDir` é `backend` e o Dockerfile está nessa pasta. Configure:
- `DATABASE_URL`: conexão Neon (não publicar)
- `APP_SECRET`: segredo aleatório com 32+ caracteres
- `SETUP_KEY`: outro segredo aleatório com 32+ caracteres
- `CORS_ORIGINS`: URL exata do frontend na Vercel, sem barra final

Após publicar, teste `https://SEU-BACKEND.onrender.com/api/health`. Isso verifica o processo, não todas as funcionalidades.

## 4. Vercel (painel)
Importe o mesmo repositório. Configure framework Vite, diretório raiz do projeto (`/`), build `npm run build`, output `dist` e variável `VITE_API_URL=https://SEU-BACKEND.onrender.com` (sem `/api`). Faça deploy e copie a URL publicada. Volte ao Render e ajuste `CORS_ORIGINS` para essa URL; publique novamente.

## 5. Criar o administrador
A configuração inicial exige `SETUP_KEY` e só funciona antes da criação do primeiro usuário. Não coloque a chave no frontend. Execute uma única vez, a partir de um terminal seguro:

```bash
curl -X POST 'https://SEU-BACKEND.onrender.com/api/setup' \
  -H 'Content-Type: application/json' \
  -H 'x-setup-key: SUA_SETUP_KEY' \
  -d '{"email":"admin@exemplo.com","password":"SENHA_FORTE_DE_12_OU_MAIS_CARACTERES"}'
```

Use um e-mail seu e senha forte exclusiva. Depois remova `SETUP_KEY` do ambiente do Render para desativar o endpoint de criação inicial. Acesse a URL Vercel e entre com as credenciais.

## Limitações e próximos passos
- **Não integrado:** WhatsApp oficial, WooCommerce, pagamentos e motor de IA.
- **Não pronto para produção:** permissões granulares, proteção contra tentativas de login, recuperação de senha, MFA, políticas LGPD, auditoria de segurança, migrações versionadas, backups/restauração, observabilidade e testes ponta a ponta.
- Render gratuito pode suspender o serviço por inatividade; cold starts são esperados.
- Confira preços/limites atuais diretamente em Render, Neon e Vercel antes de criar contas. O uso comercial da Vercel deve respeitar as condições do plano aplicável.
