# Divino IA v0.2 — backend + painel web

Projeto de desenvolvimento para a Divino Encanto Cestas e Flores. **Não está publicado na nuvem e não está pronto para produção.**

## Incluído
- API FastAPI com PostgreSQL (Docker) ou SQLite (desenvolvimento local)
- Primeiro administrador, login com token HMAC de 8h, senha scrypt com salt aleatório
- Cadastro de clientes, produtos, pedidos, controle de estoque, status, conversas e notas internas
- Configuração de automações persistida (execução real ainda não implementada)
- Painel React conectado à API; relatório básico e visão de entregas
- Auditoria básica das operações de escrita; documentação da API em `/api/docs`

## Executar localmente sem Docker
1. Python 3.11+ e Node.js 20+.
2. `cd backend && pip install -r requirements.txt`
3. Configure `APP_SECRET` com string aleatória de 32+ caracteres e `DATABASE_URL=sqlite:///./divino.db`.
4. Em `backend`, execute `uvicorn app:app --reload --port 8000`.
5. Em outro terminal, na raiz do projeto, execute `npm install && npm run dev`.
6. Abra `http://localhost:5173`, clique em **Primeiro acesso** e crie o administrador.

## Executar banco PostgreSQL e API com Docker
1. Crie `.env` (NÃO versionar), contendo `APP_SECRET`, `POSTGRES_PASSWORD` e `CORS_ORIGINS=http://localhost:5173`.
2. Execute `docker compose up --build -d`.
3. Inicie o frontend com `npm install && npm run dev`.
4. Para publicar, configure DNS, HTTPS, reverse proxy, segredos, backups, monitoramento e CORS para o domínio real. O Compose expõe a API apenas em 127.0.0.1, para uso com proxy.

## Limitações / segurança antes de operar com clientes
- **Não** integrado à Meta/WhatsApp, WooCommerce, serviços de IA, pagamentos ou frete.
- Mensagens são registros **internos**; nenhuma mensagem é enviada ao cliente.
- Fluxos marcados como habilitados são apenas configurações, sem disparo real.
- Perfis estão cadastrados, mas ainda é necessário aplicar controle de acesso granular por função, rate limiting, políticas de sessão, recuperação de senha, logs e observabilidade.
- Criar migrações de banco, testes de concorrência, transações de estoque, trilha de consentimento LGPD, políticas de retenção e backups automáticos.
- Endpoint `/api/setup` aceita criar o primeiro administrador somente quando a tabela de usuários está vazia. Proteja a primeira implantação para impedir registro indevido antes da configuração.
- Para produção, substituir o armazenamento de token em sessionStorage por sessão segura com cookie HttpOnly, Secure e proteção CSRF apropriada.
- Revisar validações de dados, limites de requisição, permissão por recurso e fluxo de cancelamento antes de uso real.
- `docker-compose.yml` é um ambiente de desenvolvimento; não inclui TLS, backups nem gerenciamento de segredos.
